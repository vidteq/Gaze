#!/bin/bash

set -o errexit

MY_PROMPT='$ '
MY_YESNO_PROMPT='(y/n)$ '

# version of the software
MAJOR_VERSION=3
MINOR_VERSION=4
# 0 Alpha, 1 Beta, 2 RC, 3 Public release
RELEASE_TYPE=0
RELEASE_BUILD=2
RELEASE_TYPE_TEXT="Alpha"

echo "This is a script to assist with installation of the Triclops SDK.";
echo "Triclops SDK package depends on the Flycapure2 (>= 2.6.3.2) package";
echo "Remember to install Flycapture2 before proceeding with Triclops installation.";
#echo "Would you like to continue and install all the Triclops SDK package?";
#echo -n "$MY_YESNO_PROMPT"
#read confirm

#if [ $confirm = "n" ] || [ $confirm = "N" ] || [ $confirm = "no" ] || [ $confirm = "No" ]
#then
#    exit 0
#    break
#fi

echo

echo "Installing Triclops packages...";

sudo dpkg -i triclops-${MAJOR_VERSION}.${MINOR_VERSION}*



echo "Complete";

#notify server of a linux installation
wget -T 10 -q --spider "http://www.ptgrey.com/support/softwarereg.asp?text=ProductName+Linux+Triclops+$MAJOR_VERSION%2E$MINOR_VERSION+$RELEASE_TYPE_TEXT+$RELEASE_BUILD+%0D%0AProductVersion+$MAJOR_VERSION%2E$MINOR_VERSION%2E$RELEASE_TYPE%2E$RELEASE_BUILD%0D%0A"

exit 0
