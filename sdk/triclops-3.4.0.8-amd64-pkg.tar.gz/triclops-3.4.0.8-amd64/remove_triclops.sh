#!/bin/bash

MY_PROMPT='$ '
MY_YESNO_PROMPT='(y/n)$ '

echo "This is a script to assist with the removal of the Triclops SDK.";
#echo "Would you like to continue and remove all the Triclops packages?";
#echo -n "$MY_YESNO_PROMPT"
#read confirm

#if [ $confirm != "y" ] && [ $confirm != "Y" ] && [ $confirm != "yes" ] && [ $confirm != "Yes" ]
#then
#    exit 0
#fi

echo

echo "Removing Triclops packages...";

sudo dpkg -r triclops3


echo "Complete";

exit 0
